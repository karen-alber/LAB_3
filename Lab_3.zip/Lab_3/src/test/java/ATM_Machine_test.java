import org.junit.Test;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class ATM_Machine_test {



    @Test
    public void check(){

        ATM_Machine atm1 = new ATM_Machine();  //after deposit
        ATM_Machine atm2 = new ATM_Machine(); //after withdraw
        ATM_Machine atm4 = new ATM_Machine(); //view balance

        assertEquals(1100 , atm1.ATM(2,0,100,1000));
        assertEquals(900 , atm2.ATM(1,100,0,1000));
        assertEquals(1000 , atm4.ATM(3,0,0,1000));
    }

}
