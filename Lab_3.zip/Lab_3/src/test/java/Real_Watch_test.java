import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Real_Watch_test {

    @Test
    public void check() {

        Real_Watch rw1 = new Real_Watch();

        // the expected of assertEquals is to enter current date and time as follows
        assertEquals("Sat May 21 07:19:00", rw1.RealWatch());

    }
}