import org.junit.Test;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Coffee_Machine_test {

    @Test
    public void check() {

        Coffee_Machine cm1 = new Coffee_Machine();  //Black Coffee
        Coffee_Machine cm2 = new Coffee_Machine(); //Milk Coffee
        Coffee_Machine cm3 = new Coffee_Machine(); //Milk and Water Coffee
        Coffee_Machine cm4 = new Coffee_Machine(); //Bottle of water

        assertEquals(20, cm1.coffee(1, 3));
        assertEquals(40, cm2.coffee(2, 1));
        assertEquals(30, cm3.coffee(3, 0));
        assertEquals(10, cm3.coffee(0, 4));

    }
}