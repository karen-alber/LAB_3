public class Coffee_Machine {

    public double coffee(int t, int sugar) {
        int coffee_powder, milk, water;
        double price = 0;
        int Coffee_Count = 0;

        switch (t) {
            // Black coffee
            case 1:
                coffee_powder = 1;
                milk = 0;
                water = 1;
                price = 20;
                break;

            // Milk coffee
            case 2:
                coffee_powder = 1;
                milk = 1;
                water = 0;
                price = 40;
                break;

            // Milk and Water coffee
            case 3:
                coffee_powder = 1;
                milk = 1;
                water = 1;
                price = 30;
                break;

            // Bottle of water
            case 0:
                coffee_powder = 0;
                milk = 0;
                water = 1;
                price = 10;
        }
        return price;
    }
}