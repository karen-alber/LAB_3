import java.util.*;
import java.text.*;


public class Real_Watch {
    public Date RealWatch() {

        String calen;

        int hours = 0, minutes = 0, seconds = 0;
        String timeString = "";

        Calendar cal = Calendar.getInstance();
        hours =cal.get(Calendar.HOUR_OF_DAY );
        if(hours >12)
            hours -=12;
        minutes =cal.get(Calendar.MINUTE );
        seconds =cal.get(Calendar.SECOND );

        SimpleDateFormat formatter = new SimpleDateFormat("hh:mm:ss");
        Date date = cal.getTime();
        timeString =formatter.format(date );

        calen = formatter + "\n" + timeString;

        return date;
    }
}