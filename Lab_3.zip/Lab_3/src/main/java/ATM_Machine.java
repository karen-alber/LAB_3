public class ATM_Machine {
    public double ATM(int choice, double withdraw, double deposit, double balance) {
        switch (choice) {
            case 1:

                if (balance >= withdraw) {
                    balance = balance - withdraw;
                } else {
                    System.out.println("Insufficient Balance");
                }

                break;

            case 2:

                balance = balance + deposit;
                break;

            case 3:
                break;

            case 4:
                //exit from the menu
                System.exit(0);
        }
        return balance;
    }
}
